package pkg1;

 public class Address {
	private String city;
	String laneNo;
	protected int pinCode;
	public String landmark;
	public static final String COUNTRY = "INDIA";
	
	Address() {
		// TODO Auto-generated constructor stub
	}
	

}
