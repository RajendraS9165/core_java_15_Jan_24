package pkg1;

public class Main {
	
	public static void main(String[] args) {
		Address add = new Address();
		//we can access public, protected and default in the same package
		
		//Test test = new Test(); can't import class in default package
	}

}
