package pkg1.invison;

public class Foo {
	
	public static void main(String[] args) {
		//Address add = new Address();
	}

}
