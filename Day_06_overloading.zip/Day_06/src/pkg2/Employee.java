package pkg2;

public class Employee {

}
