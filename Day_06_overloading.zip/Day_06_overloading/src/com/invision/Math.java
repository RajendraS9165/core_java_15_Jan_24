package com.invision;

public class Math {
	
	
	
	public void add(int num1, int num2, int num3) {
		System.out.println("int, int, int");
	}
	
	public void add(float num1, float num2) {
		System.out.println("float, float");
	}
	
	public void add(double num1, double num2) {
		System.out.println("double, double");
	}
	
	public void add(long num1, long num2) {
		System.out.println("long, long");
	}
	
	public void add(short num1, short num2) {
		System.out.println("short, short");
	}
	
	public void add(byte num1, byte num2) {
		System.out.println("byte, byte");
	}
	
	
	
//	public void add(int num1, int num2) {
//		System.out.println("int, int");
//	}

}
