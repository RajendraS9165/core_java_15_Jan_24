package com.invision;

public class Test {
	
	
	public static void main(String[] args) {
		Math math = new Math();
		math.add(10,20);
		
		
		
	}

}

